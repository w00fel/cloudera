python setup.py install --root=$RPM_BUILD_ROOT --record=INSTALLED_FILES --install-scripts=%{aws_product_path}/bin --install-data=%{aws_product_path}
